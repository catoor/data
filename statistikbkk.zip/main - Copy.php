<html><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="bangkit fajar nur alam ">
    <meta name="author" content="gudangemateri.blogspot.co.id">
    <title>Index</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <script src="jqueri/jquery-2.2.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </head><body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header page-scroll">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand page-scroll" href="#page-top"><strong>gudangemateri</strong></a>
        </div>
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav">
            <?php include "koneksi.php"; $menu=mysql_query( "SELECT * FROM menu
            ORDER BY menu_id ASC"); while($dataMenu=mysql_fetch_assoc($menu)){ 
			$menu_id=$dataMenu['menu_id']; $submenu=mysql_query("SELECT * FROM submenu WHERE
            menu_id='$menu_id' ORDER BY submenu_id ASC"); if(mysql_num_rows($submenu)==0
            ){ echo 
			'<li>
            <a href="'.$dataMenu['menu_link']. '">'.$dataMenu[ 'menu']. '</a>'; }else{ echo '
            <li class="dropdown">
              <a class="page-scroll" href="'.$dataMenu[
                            'menu_link']. '" data-toggle="dropdown">'.$dataMenu[
                            'menu']. ' <b class="caret"></b></a>
              <ul class="dropdown-menu">'; while($dataSubmenu=mysql_fetch_assoc($submenu)){ echo 
                '<li>
                  <a href="'.$dataSubmenu[
                            'submenu_link']. '">'.$dataSubmenu[ 'submenu']. '</a>
                </li>'; } echo '</ul>
            </li>'; } } ?>;</ul>
        </div>
      </div>
    </nav>
    <div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <ul class="nav nav-pills">
              <li class="active">
                <a href="#">Home</a>
              </li>
              <li>
                <a href="#">Profile</a>
              </li>
              <li>
                <a href="#">Messages</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <hr>
          </div>
        </div>
      </div>
    </div>
    <div id="konten">
      
    </div>
    <div class="section">
      <div class="container">
      <?php $pages_dir='pages'; if(!empty($_GET['p'])){ $pages=scandir($pages_dir,
      0); unset($pages[0],$pages[1]); $p=$_GET['p']; if(in_array($p.'.php',
      $pages)){ include($pages_dir. '/'.$p. '.php'); } else { echo 'Halaman tidak
      ditemukan! :('; } } else { include($pages_dir. '/home.php'); } ?>
      </div>
    </div>
  

</body></html>