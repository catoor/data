<?php
  $host = 'localhost';
  $user = 'root';
  $password = '345';
  $db = 'pengadaan_bkk';
  mysql_connect($host, $user, $password) or die ('Gagal Koneksi Ke MySQL Server');
  mysql_select_db($db) or die ('Gagal Koneksi Ke Database SIMPEG LIK');
?>

