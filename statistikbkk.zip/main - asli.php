<?php
session_start();
include('session.php');
?>
<?
$nomor=$_GET['p'];
$get_detail=mysql_query("select * from menu where menu='$nomor'");
$detail=mysql_fetch_array($get_detail);
$get_title=mysql_query("select submenu from submenu where submenu_link='$nomor'");
$title=mysql_fetch_array($get_title);
if ($nomor==asnjk){
$judul="ASN Per Kelamin";
}
else if ($nomor==perskpd){
$judul="ASN Per SKPD";
}
else if ($nomor==lappergol){
$judul="ASN Per Golongan";
}
else if ($nomor==lapeselon){
$judul="ASN Per Eselon";
}
else {
$judul="Sistem Informasi ASN Kabupaten Wonogiri";
}
?>
<html><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="bangkit fajar nur alam ">
    <meta name="author" content="gudangemateri.blogspot.co.id">
    <title><? echo $judul; ?></title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <script src="jqueri/jquery-2.2.4.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </head><body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container">
  <div class="navbar-header page-scroll">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand page-scroll" href="#page-top"><strong>Informasi Aparatur Wonogiri</strong></a>
    </div>
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav">
            <?php include "koneksi.php"; $menu=mysql_query( "SELECT * FROM menu
            ORDER BY menu_id ASC"); while($dataMenu=mysql_fetch_assoc($menu)){ 
			$menu_id=$dataMenu['menu_id']; $submenu=mysql_query("SELECT * FROM submenu WHERE
            menu_id='$menu_id' ORDER BY submenu_id ASC"); if(mysql_num_rows($submenu)==0
            ){ echo 
			'<li>
            <a href="'.$dataMenu['menu_link']. '">'.$dataMenu[ 'menu']. '</a>'; }else{ echo '
            <li class="dropdown">
              <a class="page-scroll" href="'.$dataMenu[
                            'menu_link']. '" data-toggle="dropdown">'.$dataMenu[
                            'menu']. ' <b class="caret"></b></a>
              <ul class="dropdown-menu">'; while($dataSubmenu=mysql_fetch_assoc($submenu)){ echo 
                '<li>
                  <a href="'.$dataSubmenu[
                            'submenu_link']. '">'.$dataSubmenu[ 'submenu']. '</a>
                </li>'; } echo '</ul>
            </li>'; } } ?>;</ul>
			<ul class="nav navbar-nav navbar-right"> <li><a href="#"><span class="glyphicon glyphicon-user"><?php include"profil.php"?></span> </a></li> <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li> </ul>
        </div>
      </div>
    </nav>
    <div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <ul class="nav nav-pills">
              <li class="active">
                <a href="#">Home</a>
              </li>
                   </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <hr>
          </div>
        </div>
      </div>
    </div>
    <div id="konten">
      
    </div>
    <div class="section">
      <div class="container">
      <?php $pages_dir='pages'; if(!empty($_GET['p'])){ $pages=scandir($pages_dir,
      0); unset($pages[0],$pages[1]); $p=$_GET['p']; if(in_array($p.'.php',
      $pages)){ include($pages_dir. '/'.$p. '.php'); } else { echo 'Halaman tidak
      ditemukan! :('; } } else { include($pages_dir. '/home.php'); } ?>
      </div>
    </div>
<br> 
<p> 
<footer><div class="navbar navbar-inverse navbar-fixed-bottom"> 
<div class="container">
<p style="color:#fff">
&#169; copyright Badan Kepegawaian Daerah Kabupaten Wonogiri
<a href="http://bkd.wonogirikab.go.id"></a>
</p>
</div>
</div>
</footer>
</body>

</html>