<footer class="main-footer">
	<!-- To the right -->
	<div class="pull-right hidden-xs">
		Dashboard Admin
	</div>
	<!-- Default to the left -->
	<strong>Copyright &copy; 2016 <a href="#">Achmad Chadil Auwfar</a>.</strong> All rights reserved.
</footer>