

<!DOCTYPE html>
<html>
	<head>
	  	 
	</head>
<body>
	
	  <b id="welcome"><i>Hello <?php echo $login_session; ?></i></b>
	  	
</body>
</html>