<!DOCTYPE html>
<html>
<head>
<style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>
<br>
<?
include "db.inc.php";
$sql= "SELECT  gelar_depan,nama,gelar_belakang,nip_lama,nip_baru,gol_akhir,tmt_golakhir,nama_jabatan,tmt_jabatan,mk_th,mk_bln,pendidikan_akhir,lulus,
tempat_lhr,tanggal_lhr,kod_eselon,unker_induk FROM 2016asn where jenis_jab<>'2' order by kod_golakhir desc ,kod_eselon asc,mk_th desc,mk_bln desc;"; // Menampung perintah SQL ke variabel �sql�
?>
<div id="konten">
<p>
<table border='0'>
   <tr>
      <td><table border="1">
	  <caption><h2><div align="center">DUK Struktural 2016</div></h2>
	  <h3><div align="center">Kabupaten Wonogiri</div></h3>
	  </caption>
	        <tr>
          <th>No</th>
          <th>Gelar Depan</th>
          <th>Nama&nbsp;Pegawai </th>
          <th>Gelar Belakang </th>
          <th>NIP&nbsp;Lama</th>
          <th>NIP&nbsp;Baru</th>
          <th>Gol Ruang</th>
          <th>TMT Gol Ruang</th>
          <th>Jabatan/ &nbsp;TMT Jabatan</th>
          <th>TH</th>
          <th>BL</th>
          <th>Nama&nbsp;Latihan /&nbsp;TH./&nbsp;BL</th>
          <th>Pendidikan</th>
          <th>Tahun&nbsp;Lulus</th>
          <th>Tempat / Tgl Lahir</th>
          <th>Satuan Kerja</th>
        </tr>
<?php
if ( $res = mysql_query($sql) ) {
    $no = 0; //variabel no untuk nomor urutnya.
	
    while ($row = mysql_fetch_array ($res)) {
     $no++; // ini sama saja dengan $no = $no + 1
		
         echo '<tr>';
          echo "<td>$no</td>";
          echo "<td>".$row['gelar_depan']."</td>";
		 $gdepan=$row['gelar_depan'];
		 $gbelakang=$row['gelar_belakang'];
		 $name=$row['nama'];
		 if 
		 ($gdepan =='' && $gbelakang=='') {
			  $gabung=$name;
		 }
		 
		  else if ($gdepan!='' && $gbelakang==''){
			 $gabung=$gdepan.","." ".$name;
		 }
		 else if ($gdepan =='' && $gbelakang!=''){
			 $gabung=$name.","." ".$gbelakang;
		 }
		else	
		{	
			$gabung=$gdepan.","." ".$name.","." ".$gbelakang;	
		  }
          echo "<td>".$gabung."</td>";
          echo "<td>".$row['gelar_belakang']."</td>";
          echo "<td>".$row['nip_lama']."</td>";
          echo "<td>"."'".$row['nip_baru']."</td>";
          echo "<td>".$row['gol_akhir']."</td>";
		  $tanggal=date("d-m-Y", strtotime($row['tmt_golakhir']));
          echo "<td>".$tanggal."</td>";
		  $tgl=date("d-m-Y", strtotime($row['tmt_jabatan']));
          echo "<td>".$row['nama_jabatan']."/"." ".$tgl."</td>";
          echo "<td>".$row['mk_th']."</td>";
          echo "<td>".$row['mk_bln']."</td>";
          echo "<td>".$row['']."</td>";
          echo "<td>".$row['pendidikan_akhir']."</td>";
          echo "<td>".$row['lulus']."</td>";
		  $tgllhr=date("d-m-Y", strtotime($row['tanggal_lhr']));
          echo "<td>".$row['tempat_lhr'].","." ".$tgllhr."</td>";
          echo "<td>".$row['unker_induk']."</td>";
          echo "</tr>";
		    }
         }
?>
      </table>
   
   </div>
  <body>