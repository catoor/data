<!DOCTYPE html>
<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet" />
<link href="css/dataTables.bootstrap.css" rel="stylesheet" />
<style type="text/css">
		body {
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
		}
		
		/* Table */
		table {
			margin: auto;
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
			font-size: 12px;

		}
		.demo-table {
			border-collapse: collapse;
			font-size: 13px;
		}
		.demo-table th, 
		.demo-table td {
			border-bottom: 1px solid #e1edff;
			border-left: 1px solid #e1edff;
			padding: 10px 20px;
		}
		.demo-table th, 
		.demo-table td:last-child {
			border-right: 1px solid #e1edff;
		}
		.demo-table td:first-child {
			border-top: 1px solid #e1edff;
		}
		.demo-table td:last-child{
			border-bottom: 0;
		}
		caption {
			caption-side: top;
			margin-bottom: 10px;
		}
		
		/* Table Header */
		.demo-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}
		
		/* Table Body */
		.demo-table tbody td {
			color: #353535;
		}
		
		.demo-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.demo-table tbody tr:hover th,
		.demo-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
			transition: all .2s;
		}
	</style>
</head>
<body>
<br>
<?
include "db.inc.php";
$sql= "SELECT * FROM dbasn1217 where status_pns='1' or status_pns='2' order by jenis_jab,eselon asc"; // Menampung perintah SQL ke variabel �sql�
?>
<div id="konten">
<p>
<p><a href="xport.php"><button>Export Data ke Excel</button></a></p>
<div class="container">
	<!--<section class="col-lg-15">-->
	<caption><h2><div align="center">Data PNS Aktif Kabupaten Wonogiri<p><h3>Tahun 2017</h3></div></h2>
	  <h3><div align="center"></div></h3>
	  </caption>
		<div class="table">
			<div class="page-header">
			
	<table id="example1" class="table table-striped table-bordered table-hover">
                                    
      <!--<td><table border="1">-->
	  
	  <div class="col-md-8 col-md-offset-2">
	  <thead>
	       <tr class="danger">
          <th>No</th>
          <th>Nip</th>
		  <!--<th>gdepan</th>-->
          <th>Nama PNS</th>
		  <!--<th>Gbelakang</th>-->
          <th>Golongan</th>
          <th>Eselon</th>
          <th>Jabatan</th>
          <th>Unker</th>
		  <th>Sub Unker</th>
            </tr>
</thead>
<tbody>
<?php
if ( $res = mysql_query($sql) ) {
    $no = 0; //variabel no untuk nomor urutnya.
	
    while ($row = mysql_fetch_array ($res)) {
     $no++; // ini sama saja dengan $no = $no + 1
		
         echo '<tr>';
          echo "<td>$no</td>";
          echo "<td>".$row['nip_baru']."</td>";
		  //echo "<td>".$row['Gelar_depan']."</td>";
          //echo "<td>".$row['nama']."</td>";
		  $gdepan=$row['Gelar_depan'];
		  $gbelakang=$row['Gelar_Belakang'];
		  $name=$row['nama'];
		  if 
		 ($gdepan =='' && $gbelakang=='') {
			  $gabung=$name;
		 }
		 
		  else if ($gdepan!='' && $gbelakang==''){
			 $gabung=$gdepan.","." ".$name;
		 }
		 else if ($gdepan =='' && $gbelakang!=''){
			 $gabung=$name.","." ".$gbelakang;
		 }
		else	
		{	
			$gabung=$gdepan.","." ".$name.","." ".$gbelakang;	
		  }
		  echo "<td>".$gabung."</td>";
		  //echo "<td>".$row['Gelar_Belakang']."</td>";
          //$tanggal=date("d-m-Y", strtotime($row['tmt_jabatan']));
          //echo "<td>".$tanggal."</td>";
          echo "<td>".$row['gol_akhir']."</td>";
		 $pendnama=$row['Eselon'];
		 if ($pendnama ==21)
   {
    $obah="II.a"; //diskon 0%
   }
   else if ($pendnama ==22)
   {
    $obah ="II.b"; //diskon 15%
   }
   else if ($pendnama ==31){
	   $obah ="III.a";
   }
   else if ($pendnama ==32){
	   $obah ="III.b";
   }
   else if ($pendnama ==41){
	   $obah ="IV.a";
   }
   else if ($pendnama ==42){
	   $obah ="IV.b";
   }
   else if ($pendnama ==51){
	   $obah ="V.a";
   }
   else if ($pendnama ==02){
	   $obah ="JFT";
   }
   else if ($pendnama ==03){
	   $obah ="JFU";
   }
      else{
	   $obah = CPNS;
   }
          echo "<td>".$obah."</td>";
          echo "<td>".$row['nama_jabatan']."</td>";
          echo "<td>".$row['unker_induk']."</td>";
		  echo "<td>".$row['unker']."</td>";
          echo "</tr>";
		    }
         }
?>
</tbody>
  </table>
   </div>
   </div>
     <!--<script src="js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <!--<script src="js/bootstrap.min.js"></script>-->
    <script src="js/jquery.dataTables.js"></script>
    <script src="js/dataTables.bootstrap.js"></script>
    <script>
            $(document).ready(function () {
                $('#example1').dataTable();
            });
    </script>
  </body>
</html>