<!DOCTYPE html>
<html>
<head>
<style type="text/css">>
body {
			font-family: "Times New Roman", "Lucida Grande", "Segoe Ui";
		}
		
		/* Table */
		table {
			margin: auto;
			font-family: "Arial", "Lucida Grande", "Segoe Ui";
			font-size: 12px;
            text-align: center;
	        vertical-align: middle;
		}
		.demo-table {
			border-collapse: collapse;
			font-size: 12px;
		}
		.demo-table th, 
		.demo-table td {
			border-bottom: 1px solid #e1edff;
			border-left: 1px solid #e1edff;
			padding: 7px 17px;
		}
		.demo-table th, 
		.demo-table td:last-child {
			border-right: 1px solid #e1edff;
		}
		.demo-table td:first-child {
			border-top: 1px solid #e1edff;
		}
		.demo-table td:last-child{
			border-bottom: 0;
		}
		caption {
			caption-side: top;
			margin-bottom: 10px;
		}
		
		/* Table Header */
		.demo-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #7ea1cc !important;
			text-transform: uppercase;
		}
		
		/* Table Body */
		.demo-table tbody td {
			color: #353535;
		}
		
		.demo-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.demo-table tbody tr:hover th,
		.demo-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #fff21f;
			transition: all .2s;
		}
		.container{
	    display: table;
        }
      .box{
	   display: table-cell;
	   text-align: center;
	   vertical-align: middle;
	   border:50px solid rgba(0,0,0,.2);
         }
</style>
</head>
<body>
<?php $bulan = array(
                '1' => 'JANUARI',
                '2' => 'FEBRUARI',
                '3' => 'MARET',
                '4' => 'APRIL',
                '5' => 'MEI',
                '6' => 'JUNI',
                '7' => 'JULI',
                '8' => 'AGUSTUS',
                '9' => 'SEPTEMBER',
                '10' => 'OKTOBER',
                '11' => 'NOVEMBER',
                '12' => 'DESEMBER',
        );?>

		 
		  </tr>
		</thead>
	<tbody>			
<?php
session_start();
include "db.inc.php";

$sql = "CREATE temporary table performasi select daftar.kode_daftar,daftar.formasi,daftar.tingkat_pendidikan,tingkat_pendidikan.nama,tgl_add from daftar join tingkat_pendidikan on daftar.tingkat_pendidikan=tingkat_pendidikan.kode order by formasi";  
$tem= mysql_query($sql);
$no = 1;
// nilai awal jumlah total karyawan


?>
</tbody>
</table>
</div>
<br>
<p>
<div class="container">
	<section class="col-lg-12">
		<div class="table-responsive">
			<div class="page-header">
				<h4><div align="center">REKAP JUMLAH PELAMAR BKK PER PENDIDIKAN  <?php  echo ' '.(ucwords($bulan[date("m")-0])).' '.date('Y') ?></div></h4>
				<h4></h4>
			</div>
		
	    
<table id="example1" class="table table-bordered">
		<thead>
		  <tr class="danger">
          <th rowspan="2" class="text-center">No</th>
          <th rowspan="2" class="text-center">TINGKAT PENDIDIKAN</th>
          <th colspan="5" class="text-center">FORMASI</th>
		  <th rowspan="2" class="text-center">JUMLAH</th>
          </tr>
		  <tr class="danger">
		  <th class="text-center">PEMASARAN</th>
          <th class="text-center">STAF IT</th>
		  <th class="text-center">STAF ADMINISTRASI</th>
		  <th class="text-center">TELLER</th>
		  <th class="text-center">SATPAM</th>
		 
		  </tr>
		</thead>
	<tbody>			
<?php

$no = 1;
// nilai awal jumlah total karyawan
$totalPNSL = 0;
$totalPNSP = 0;
$totalpns=0;
$query = "SELECT tingkat_pendidikan,nama FROM performasi group by tingkat_pendidikan";
$hasil = mysql_query($query);
while ($data = mysql_fetch_array($hasil))
{
  $pendnama=$data['tingkat_pendidikan'];
  $pendnama2=$data['nama'];
  $query1 = "SELECT count(*) as jum FROM performasi WHERE tingkat_pendidikan = '$pendnama'";
  $hasil1 = mysql_query($query1);
  $data1 = mysql_fetch_array($hasil1);
  $jumlah = $data1['jum'];
  $totalpns +=$jumlah;
  
  $query2 = "SELECT count(*) as jump1 FROM performasi WHERE formasi = '01' and tingkat_pendidikan = '$pendnama'";
  $hasil2 = mysql_query($query2);
  $data2 = mysql_fetch_array($hasil2);
  $jump1 = $data2['jump1'];
  $totpnsp1 +=$jump1;
  
  $query3 = "SELECT count(*) as jump2 FROM performasi WHERE formasi = '02' and tingkat_pendidikan = '$pendnama'";
  $hasil3 = mysql_query($query3);
  $data3 = mysql_fetch_array($hasil3);
  $jump2 = $data3['jump2'];
  $totpnsp2 +=$jump2;
  
  $query4 = "SELECT count(*) as jump3 FROM performasi WHERE formasi = '03' and tingkat_pendidikan = '$pendnama'";
  $hasil4 = mysql_query($query4);
  $data4 = mysql_fetch_array($hasil4);
  $jump3 = $data4['jump3'];
  $totpnsp3 +=$jump3;
  
  $query5 = "SELECT count(*) as jump4 FROM performasi WHERE formasi = '04' and tingkat_pendidikan = '$pendnama'";
  $hasil5 = mysql_query($query5);
  $data5 = mysql_fetch_array($hasil5);
  $jump4 = $data5['jump4'];
  $totpnsp4 +=$jump4;
  $query6 = "SELECT count(*) as jump5 FROM performasi WHERE formasi = '05' and tingkat_pendidikan = '$pendnama'";
  $hasil6 = mysql_query($query6);
  $data6 = mysql_fetch_array($hasil6);
  $jump5 = $data6['jump5'];
  $totpnsp5 +=$jump5;
 
  echo "<tr><td>".$no."</td><td>".$pendnama2."</td><td class='text-center'>".$jump1."</td><td class='text-center'>".$jump2."</td><td class='text-center'>".$jump3."</td><td class='text-center'>".$jump4."</td><td class='text-center'>".$jump5."</td><td class='text-center'>".$jumlah."</td>";
 
  // increment untuk nomor urut data
  $no++;
}
echo "<tr class='warning'><td colspan='2' align='center'>Jumlah</td><td class='text-center'>".$totpnsp1."</td><td class='text-center'>".$totpnsp2."</td><td class='text-center'>".$totpnsp3."</td><td class='text-center'>".$totpnsp4."</td><td class='text-center'>".$totpnsp5."</td><td class='text-center'>".$totalpns."</td>";
 
// membuat akhir dari tabel

?>
</tbody>
</table>
</div>
<p>
<br>
<div class="container">
	<section class="col-lg-12">
		<div class="table-responsive">
			<div class="page-header">
				<h4><div align="center">REKAP JUMLAH PELAMAR BKK MEMENUHI SYARAT (MS) PER PENDIDIKAN  <?php  echo ' '.(ucwords($bulan[date("m")-0])).' '.date('Y') ?></div></h4>
				<h4></h4>
			</div>
		
	    
<table id="example1" class="table table-bordered">
		<thead>
		  <tr class="danger">
          <th rowspan="2" class="text-center">No</th>
          <th rowspan="2" class="text-center">TINGKAT PENDIDIKAN</th>
          <th colspan="5" class="text-center">FORMASI</th>
		  <th rowspan="2" class="text-center">JUMLAH</th>
          </tr>
		  <tr class="danger">
		  <th class="text-center">PEMASARAN</th>
          <th class="text-center">STAF IT</th>
		  <th class="text-center">STAF ADMINISTRASI</th>
		  <th class="text-center">TELLER</th>
		  <th class="text-center">SATPAM</th>
		 
		  </tr>
		</thead>
	<tbody>			
<?php
session_start();
include "db.inc.php";

$sqlms = "CREATE temporary table performasims select daftar.kode_daftar,daftar.formasi,daftar.tingkat_pendidikan,tingkat_pendidikan.nama,daftar.uservalidasi from daftar join tingkat_pendidikan on daftar.tingkat_pendidikan=tingkat_pendidikan.kode  where daftar.`status`='1' order by formasi";  
$temms= mysql_query($sqlms);
$no = 1;
// nilai awal jumlah total karyawan
$totalPNSL = 0;
$totalPNSP = 0;
$totalpns=0;
$queryms = "SELECT tingkat_pendidikan,nama FROM performasims group by tingkat_pendidikan";
$hasilms = mysql_query($queryms);
while ($datams = mysql_fetch_array($hasilms))
{
  $pendnamams=$datams['tingkat_pendidikan'];
  $pendnama2ms=$datams['nama'];
  $query1ms = "SELECT count(*) as jumms FROM performasims WHERE tingkat_pendidikan = '$pendnamams'";
  $hasil1ms = mysql_query($query1ms);
  $data1ms = mysql_fetch_array($hasil1ms);
  $jumlahms = $data1ms['jumms'];
  $totalpnsms +=$jumlahms;
  
  $query2ms = "SELECT count(*) as jump1ms FROM performasims WHERE formasi = '01' and tingkat_pendidikan = '$pendnamams'";
  $hasil2ms = mysql_query($query2ms);
  $data2ms = mysql_fetch_array($hasil2ms);
  $jump1ms = $data2ms['jump1ms'];
  $totpns1ms +=$jump1ms;
  
  $query3ms = "SELECT count(*) as jump2ms FROM performasims WHERE formasi = '02' and tingkat_pendidikan = '$pendnamams'";
  $hasil3ms = mysql_query($query3ms);
  $data3ms = mysql_fetch_array($hasil3ms);
  $jump2ms = $data3ms['jump2ms'];
  $totpns2ms +=$jump2ms;
  
  $query4ms = "SELECT count(*) as jump3ms FROM performasims WHERE formasi = '03' and tingkat_pendidikan = '$pendnamams'";
  $hasil4ms = mysql_query($query4ms);
  $data4ms = mysql_fetch_array($hasil4ms);
  $jump3ms = $data4ms['jump3ms'];
  $totpns3ms +=$jump3ms;
  
  $query5ms = "SELECT count(*) as jump4ms FROM performasims WHERE formasi = '04' and tingkat_pendidikan = '$pendnamams'";
  $hasil5ms = mysql_query($query5ms);
  $data5ms = mysql_fetch_array($hasil5ms);
  $jump4ms = $data5ms['jump4ms'];
  $totpns4ms +=$jump4ms;
  
  $query6ms = "SELECT count(*) as jump5ms FROM performasims WHERE formasi = '05' and tingkat_pendidikan = '$pendnamams'";
  $hasil6ms = mysql_query($query6ms);
  $data6ms = mysql_fetch_array($hasil6ms);
  $jump5ms = $data6ms['jump5ms'];
  $totpns5ms +=$jump5ms;
 
  echo "<tr><td>".$no."</td><td>".$pendnama2ms."</td><td class='text-center'>".$jump1ms."</td><td class='text-center'>".$jump2ms."</td><td class='text-center'>".$jump3ms."</td><td class='text-center'>".$jump4ms."</td><td class='text-center'>".$jump5ms."</td><td class='text-center'>".$jumlahms."</td>";
 
  // increment untuk nomor urut data
  $no++;
}
echo "<tr class='warning'><td colspan='2' align='center'>Jumlah</td><td class='text-center'>".$totpns1ms."</td><td class='text-center'>".$totpns2ms."</td><td class='text-center'>".$totpns3ms."</td><td class='text-center'>".$totpns4ms."</td><td class='text-center'>".$totpns5ms."</td><td class='text-center'>".$totalpnsms."</td>";
 
// membuat akhir dari tabel

?>
</tbody>
</table>
<p>

<div class="container">
	<section class="col-lg-12">
		<div class="table-responsive">
			<div class="page-header">
				<h4><div align="center">REKAP JUMLAH PELAMAR BKK TIDAK MEMENUHI SYARAT (TMS) PER PENDIDIKAN  <?php  echo ' '.(ucwords($bulan[date("m")-0])).' '.date('Y') ?></div></h4>
				<h4></h4>
			</div>
		
	    
<table id="example1" class="table table-bordered">
		<thead>
		  <tr class="danger">
          <th rowspan="2" class="text-center">No</th>
          <th rowspan="2" class="text-center">TINGKAT PENDIDIKAN</th>
          <th colspan="5" class="text-center">FORMASI</th>
		  <th rowspan="2" class="text-center">JUMLAH</th>
          </tr>
		  <tr class="danger">
		  <th class="text-center">PEMASARAN</th>
          <th class="text-center">STAF IT</th>
		  <th class="text-center">STAF ADMINISTRASI</th>
		  <th class="text-center">TELLER</th>
		  <th class="text-center">SATPAM</th>
		 
		  </tr>
		</thead>
	<tbody>			
<?php
session_start();
include "db.inc.php";

$sqltms = "CREATE temporary table performasitms select daftar.kode_daftar,daftar.formasi,daftar.tingkat_pendidikan,tingkat_pendidikan.nama,daftar.uservalidasi from daftar join tingkat_pendidikan on daftar.tingkat_pendidikan=tingkat_pendidikan.kode  where daftar.`status`='0' order by formasi";  
$temtms= mysql_query($sqltms);
$no = 1;
// nilai awal jumlah total karyawan
$totalPNSL = 0;
$totalPNSP = 0;
$totalpns=0;
$querytms = "SELECT tingkat_pendidikan,nama FROM performasitms group by tingkat_pendidikan";
$hasiltms = mysql_query($querytms);
while ($datatms = mysql_fetch_array($hasiltms))
{
  $pendnamatms=$datatms['tingkat_pendidikan'];
  $pendnama2tms=$datatms['nama'];
  $query1tms = "SELECT count(*) as jumtms FROM performasitms WHERE tingkat_pendidikan = '$pendnamatms'";
  $hasil1tms = mysql_query($query1tms);
  $data1tms = mysql_fetch_array($hasil1tms);
  $jumlahtms = $data1tms['jumtms'];
  $totalpnstms +=$jumlahtms;
  
  $query2tms = "SELECT count(*) as jump1tms FROM performasitms WHERE formasi = '01' and tingkat_pendidikan = '$pendnamatms'";
  $hasil2tms = mysql_query($query2tms);
  $data2tms = mysql_fetch_array($hasil2tms);
  $jump1tms = $data2tms['jump1tms'];
  $totpnsp1tms +=$jump1tms;
  
  $query3tms = "SELECT count(*) as jump2tms FROM performasitms WHERE formasi = '02' and tingkat_pendidikan = '$pendnamatms'";
  $hasil3tms = mysql_query($query3tms);
  $data3tms = mysql_fetch_array($hasil3tms);
  $jump2tms = $data3tms['jump2tms'];
  $totpnsp2tms +=$jump2tms;
  
  $query4tms = "SELECT count(*) as jump3tms FROM performasitms WHERE formasi = '03' and tingkat_pendidikan = '$pendnamatms'";
  $hasil4tms = mysql_query($query4tms);
  $data4tms = mysql_fetch_array($hasil4tms);
  $jump3tms = $data4tms['jump3tms'];
  $totpnsp3tms +=$jump3tms;
  
  $query5tms = "SELECT count(*) as jump4tms FROM performasitms WHERE formasi = '04' and tingkat_pendidikan = '$pendnamatms'";
  $hasil5tms = mysql_query($query5tms);
  $data5tms = mysql_fetch_array($hasil5tms);
  $jump4tms = $data5tms['jump4tms'];
  $totpnsp4tms +=$jump4tms;
  
  $query6tms = "SELECT count(*) as jump5tms FROM performasitms WHERE formasi = '05' and tingkat_pendidikan = '$pendnamatms'";
  $hasil6tms = mysql_query($query6tms);
  $data6tms = mysql_fetch_array($hasil6tms);
  $jump5tms = $data6tms['jump5tms'];
  $totpnsp5tms +=$jump5tms;
 
  echo "<tr><td>".$no."</td><td>".$pendnama2tms."</td><td class='text-center'>".$jump1tms."</td><td class='text-center'>".$jump2tms."</td><td class='text-center'>".$jump3tms."</td><td class='text-center'>".$jump4tms."</td><td class='text-center'>".$jump5tms."</td><td class='text-center'>".$jumlahtms."</td>";
 
  // increment untuk nomor urut data
  $no++;
}
echo "<tr class='warning'><td colspan='2' align='center'>Jumlah</td><td class='text-center'>".$totpnsp1tms."</td><td class='text-center'>".$totpnsp2tms."</td><td class='text-center'>".$totpnsp3tms."</td><td class='text-center'>".$totpnsp4tms."</td><td class='text-center'>".$totpnsp5tms."</td><td class='text-center'>".$totalpnstms."</td>";
 
// membuat akhir dari tabel

?>
</tbody>
</table>
<p>
<br>
<div class="container">
	<section class="col-lg-12">
		<div class="table-responsive">
			<div class="page-header">
				<h4><div align="center">REKAP JUMLAH PELAMAR BKK BELUM VERIFIKASI PER PENDIDIKAN  <?php  echo ' '.(ucwords($bulan[date("m")-0])).' '.date('Y') ?></div></h4>
				<h4></h4>
			</div>
		
	    
<table id="example1" class="table table-bordered">
		<thead>
		  <tr class="danger">
          <th rowspan="2" class="text-center">No</th>
          <th rowspan="2" class="text-center">TINGKAT PENDIDIKAN</th>
          <th colspan="5" class="text-center">FORMASI</th>
		  <th rowspan="2" class="text-center">JUMLAH</th>
          </tr>
		  <tr class="danger">
		  <th class="text-center">PEMASARAN</th>
          <th class="text-center">STAF IT</th>
		  <th class="text-center">STAF ADMINISTRASI</th>
		  <th class="text-center">TELLER</th>
		  <th class="text-center">SATPAM</th>
		 
		  </tr>
		</thead>
	<tbody>			
<?php
session_start();
include "db.inc.php";

$sqlblm = "CREATE temporary table performasiblm select daftar.kode_daftar,daftar.formasi,daftar.tingkat_pendidikan,tingkat_pendidikan.nama,daftar.uservalidasi from daftar join tingkat_pendidikan on daftar.tingkat_pendidikan=tingkat_pendidikan.kode  where daftar.`status` is NULL order by formasi";  
$temblm= mysql_query($sqlblm);
$no = 1;
// nilai awal jumlah total karyawan
$totalPNSL = 0;
$totalPNSP = 0;
$totalpns=0;
$queryblm = "SELECT tingkat_pendidikan,nama FROM performasiblm group by tingkat_pendidikan";
$hasilblm = mysql_query($queryblm);
while ($datablm = mysql_fetch_array($hasilblm))
{
  $pendnamablm=$datablm['tingkat_pendidikan'];
  $pendnama2blm=$datablm['nama'];
  $query1blm = "SELECT count(*) as jumblm FROM performasiblm WHERE tingkat_pendidikan = '$pendnamablm'";
  $hasil1blm = mysql_query($query1blm);
  $data1blm = mysql_fetch_array($hasil1blm);
  $jumlahblm = $data1blm['jumblm'];
  $totalpnsblm +=$jumlahblm;
  
  $query2blm = "SELECT count(*) as jump1blm FROM performasiblm WHERE formasi = '01' and tingkat_pendidikan = '$pendnamablm'";
  $hasil2blm = mysql_query($query2blm);
  $data2blm = mysql_fetch_array($hasil2blm);
  $jump1blm = $data2blm['jump1blm'];
  $totpnsp1blm +=$jump1blm;
  
  $query3blm = "SELECT count(*) as jump2blm FROM performasiblm WHERE formasi = '02' and tingkat_pendidikan = '$pendnamablm'";
  $hasil3blm = mysql_query($query3blm);
  $data3blm = mysql_fetch_array($hasil3blm);
  $jump2blm = $data3blm['jump2blm'];
  $totpnsp2blm +=$jump2blm;
  
  $query4blm = "SELECT count(*) as jump3blm FROM performasiblm WHERE formasi = '03' and tingkat_pendidikan = '$pendnamablm'";
  $hasil4blm = mysql_query($query4blm);
  $data4blm = mysql_fetch_array($hasil4blm);
  $jump3blm = $data4blm['jump3blm'];
  $totpnsp3blm +=$jump3blm;
  
  $query5blm = "SELECT count(*) as jump4blm FROM performasiblm WHERE formasi = '04' and tingkat_pendidikan = '$pendnamablm'";
  $hasil5blm = mysql_query($query5blm);
  $data5blm = mysql_fetch_array($hasil5blm);
  $jump4blm = $data5blm['jump4blm'];
  $totpnsp4blm +=$jump4blm;
  
  $query6blm = "SELECT count(*) as jump5blm FROM performasiblm WHERE formasi = '05' and tingkat_pendidikan = '$pendnamablm'";
  $hasil6blm = mysql_query($query6blm);
  $data6blm = mysql_fetch_array($hasil6blm);
  $jump5blm = $data6blm['jump5blm'];
  $totpnsp5blm +=$jump5blm;
 
  echo "<tr><td>".$no."</td><td>".$pendnama2blm."</td><td class='text-center'>".$jump1blm."</td><td class='text-center'>".$jump2blm."</td><td class='text-center'>".$jump3blm."</td><td class='text-center'>".$jump4blm."</td><td class='text-center'>".$jump5blm."</td><td class='text-center'>".$jumlahblm."</td>";
 
  // increment untuk nomor urut data
  $no++;
}
echo "<tr class='warning'><td colspan='2' align='center'>Jumlah</td><td class='text-center'>".$totpnsp1blm."</td><td class='text-center'>".$totpnsp2blm."</td><td class='text-center'>".$totpnsp3blm."</td><td class='text-center'>".$totpnsp4blm."</td><td class='text-center'>".$totpnsp5blm."</td><td class='text-center'>".$totalpnsblm."</td>";
 
// membuat akhir dari tabel

?>
</tbody>
</table>
</body>	