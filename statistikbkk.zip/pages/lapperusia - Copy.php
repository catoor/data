<!DOCTYPE html>
<html>
<head>
<style type="text/css">>
body {
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
		}
		
		/* Table */
		table {
			margin: auto;
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
			font-size: 14px;

		}
		.demo-table {
			border-collapse: collapse;
			font-size: 25px;
		}
		.demo-table th, 
		.demo-table td {
			border-bottom: 1px solid #e1edff;
			border-left: 1px solid #e1edff;
			padding: 15px 25px;
		}
		.demo-table th, 
		.demo-table td:last-child {
			border-right: 1px solid #e1edff;
		}
		.demo-table td:first-child {
			border-top: 1px solid #e1edff;
		}
		.demo-table td:last-child{
			border-bottom: 0;
		}
		caption {
			caption-side: top;
			margin-bottom: 10px;
		}
		
		/* Table Header */
		.demo-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}
		
		/* Table Body */
		.demo-table tbody td {
			color: #353535;
		}
		
		.demo-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.demo-table tbody tr:hover th,
		.demo-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
			transition: all .2s;
		}
</style>
</head>
<body>
<?php $bulan = array(
                '1' => 'JANUARI',
                '2' => 'FEBRUARI',
                '3' => 'MARET',
                '4' => 'APRIL',
                '5' => 'MEI',
                '6' => 'JUNI',
                '7' => 'JULI',
                '8' => 'AGUSTUS',
                '9' => 'SEPTEMBER',
                '10' => 'OKTOBER',
                '11' => 'NOVEMBER',
                '12' => 'DESEMBER',
        );?>
<td><table border="1" align="center">
<caption><h4><div align="center">Rekap PNS Per Usia</div></h4>
<h3><div align="center">Bulan <?php  echo ' '.(ucwords($bulan[date("m")-1])).' '.date('Y') ?></div></h3>
</caption>
<tr>
<th>NO</th>
<th>Range Usia</th>
<th>LAKI-LAKI</th>
<th>PEREMPUAN</th>
<th>JUMLAH</th>
 </tr>
				
<?php
session_start();
include "db.inc.php";

$sql = "CREATE temporary table temp_usia select nip_baru,nama,jkel,tanggal_lhr,ELT( FLOOR(TIMESTAMPDIFF(YEAR,tanggal_lhr,CURDATE())/11),'1-16', '17-37','38-47','48-57','58-60') AS range_umur from dbasn where status_pns='1' or status_pns='2'";  
$tem= mysql_query($sql);
$no = 1;
// nilai awal jumlah total karyawan
$totalPNSL = 0;
$totalPNSP = 0;
$totalpns=0;
$query = "SELECT nip_baru,range_umur FROM temp_usia group by range_umur";
$hasil = mysql_query($query);
while ($data = mysql_fetch_array($hasil))
{
  $pendnama=$data['range_umur'];
   $query1 = "SELECT count(*) as jum FROM temp_usia WHERE range_umur = '$pendnama'";
  $hasil1 = mysql_query($query1);
  $data1 = mysql_fetch_array($hasil1);
  $jumlah = $data1['jum'];
  $totalpns += $jumlah;
  $query2 = "SELECT count(*) as jum2 FROM temp_usia WHERE jkel = 'L' and range_umur = '$pendnama'";
  $hasil2 = mysql_query($query2);
  $data2 = mysql_fetch_array($hasil2);
  $jumL = $data2['jum2'];
  $totalPNSL +=$jumL;
  
  $query3 = "SELECT count(*) as jum3 FROM temp_usia WHERE jkel = 'P' and range_umur = '$pendnama'";
  $hasil3 = mysql_query($query3);
  $data3 = mysql_fetch_array($hasil3);
  $jumP = $data3['jum3'];
  $totalPNSP +=$jumP;
  
  echo "<tr><td>".$no."</td><td>".$pendnama."</td><td>".$jumL."</td><td>".$jumP."</td><td>".$jumlah."</td>";
 
  // increment untuk nomor urut data
  $no++;
}
echo "<tr><td colspan='2' align='center'>Total</td><td>".$totalPNSL."</td><td>".$totalPNSP."</td><td>".$totalpns."</td>";
 
// membuat akhir dari tabel

?>
</table>
<br>
<p>
</body>	