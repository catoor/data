<!DOCTYPE html>
<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet" />
<link href="css/dataTables.bootstrap.css" rel="stylesheet" />
<style type="text/css">
		body {
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
		}
		
		/* Table */
		table {
			margin: auto;
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
			font-size: 12px;

		}
		.demo-table {
			border-collapse: collapse;
			font-size: 13px;
		}
		.demo-table th, 
		.demo-table td {
			border-bottom: 1px solid #e1edff;
			border-left: 1px solid #e1edff;
			padding: 10px 20px;
		}
		.demo-table th, 
		.demo-table td:last-child {
			border-right: 1px solid #e1edff;
		}
		.demo-table td:first-child {
			border-top: 1px solid #e1edff;
		}
		.demo-table td:last-child{
			border-bottom: 0;
		}
		caption {
			caption-side: top;
			margin-bottom: 10px;
		}
		
		/* Table Header */
		.demo-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}
		
		/* Table Body */
		.demo-table tbody td {
			color: #353535;
		}
		
		.demo-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.demo-table tbody tr:hover th,
		.demo-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
			transition: all .2s;
		}
	</style>
</head>
<body>
<br>
<?php
include "db.inc.php";
$sql= "create  temporary table onde 
SELECT daftar.kode_daftar,daftar.nama,daftar.tgl_lahir,daftar.`status`,formasi.nama_formasi,pendidikan.nama_pendidikan,
CONCAT_WS('',daftar.tmsket,daftar.tmsket2,daftar.tmsket3,daftar.tmsket4) as alasan,daftar.tmsket5 as alasan2 from daftar
left join formasi on daftar.formasi=formasi.kode_for join pendidikan on daftar.pendidikan=pendidikan.cepat_kode where daftar.status='0'";
 // Menampung perintah SQL ke variabel �sql�
$tem= mysql_query($sql);
//$das2 = mysql_fetch_array($das);
//$form=$das2[pendidikan] ;


?>
<div id="konten">
<p>
<p><a href="xport.php"><button>Export Data ke Excel</button></a></p>
<div class="container">
	<!--<section class="col-lg-15">-->
	<caption><h2><div align="center">Nominatif TMS Pengadaan BKK <p><h3>Tahun 2019</h3></div></h2>
	  <h3><div align="center"></div></h3>
	  </caption>
		<div class="table">
			<div class="page-header">
			
	<table id="example1" class="table table-striped table-bordered table-hover">
                                    
      <!--<td><table border="1">-->
	  
	  <div class="col-md-8 col-md-offset-2">
	  <thead>
	       <tr class="danger">
          <th>No</th>
          <th>No Berkas Masuk</th>
		  <!--<th>gdepan</th>-->
          <th>Nama Pelamar</th>
		  <!--<th>Gbelakang</th>-->
          <th>Tanggal Lahir</th>
          <th>Pendidikan</th>
          <th>Formasi</th>
		  <th>Keterangan TMS</th>
		  <th>Ket TMS 2</th>
          </tr>
</thead>
<tbody>
<?php
$query="select * from onde";
if ( $res = mysql_query($query) ) {
    $no = 0; //variabel no untuk nomor urutnya.
	
    while ($row = mysql_fetch_array ($res)) {
     $no++; // ini sama saja dengan $no = $no + 1
		$statbtl=str_split($row[alasan]);
        $pend=$row['pendidikan'];
		$als=$row['alasan2'];
		//$qket="select NAMA from dikformasi where CEPAT_KODE='$form'";
			//$rket=mysql_query($qket) or die(mysql_error());
			//$roket=mysql_fetch_row($rket);
          //echo "<td>".$roket."</td>";     
         //echo <td></td>;
          //echo "</tr>";
?>
 <tr>
          <td><?=$no?></td>
         <td><?=$row['kode_daftar']?></td>
		  <td><?=$row['nama']?></td>
		  <?php $tanggal=date('d-m-Y', strtotime($row['tgl_lahir']));?>
		  <td><?=$tanggal?></td>
		  <td><?=$row['nama_pendidikan']?></td> 
		  <td><?=$row['nama_formasi']?></td> 
		  <td><?php for ($j=0;$j < count($statbtl);$j++) {
			$qket="select keterangan from tmsket where id='$statbtl[$j]'";
			$rket=mysql_query($qket) or die(mysql_error());
		  $roket=mysql_fetch_row($rket);
		  ?>
		 <li><?=$roket[0] ?></li><?}?>
		</td>
		 <td><?=$row['alasan2']?></td>
		 </tr>
	<?php }?>
<?php }?>	
</tbody>
  </table>
   </div>
   </div>
     <!--<script src="js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <!--<script src="js/bootstrap.min.js"></script>-->
    <script src="js/jquery.dataTables.js"></script>
    <script src="js/dataTables.bootstrap.js"></script>
    <script>
            $(document).ready(function () {
                $('#example1').dataTable({"iDisplayLength": 10,
    "aLengthMenu": [[10, 25, 50, -1], [5, 10, 25, 50, "All"]]});
            });
    </script>
  </body>
</html>