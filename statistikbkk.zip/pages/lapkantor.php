<!DOCTYPE html>
<html>
<head>
<style>
table {
    border-collapse: collapse;
    width: auto;
}

th, td {
    text-align: left;
    padding: 4px 20px;
	
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>
<?php $bulan = array(
                '1' => 'JANUARI',
                '2' => 'FEBRUARI',
                '3' => 'MARET',
                '4' => 'APRIL',
                '5' => 'MEI',
                '6' => 'JUNI',
                '7' => 'JULI',
                '8' => 'AGUSTUS',
                '9' => 'SEPTEMBER',
                '10' => 'OKTOBER',
                '11' => 'NOVEMBER',
                '12' => 'DESEMBER',
        );?>
<td><table border="1" align="center">
<caption><h2><div align="center">Rekap PNS Per Kelompok OPD</div></h2>
<h3><div align="center">Bulan <?php  echo ' '.(ucwords($bulan[date("m")-1])).' '.date('Y') ?></div></h3>
</caption>


<tr>
<th>NO</th>
<th>KELOMPOK OPD</th>
<th>LAKI-LAKI</th>
<th>PEREMPUAN</th>
<th>JUMLAH</th>
 </tr>
				
<?php
session_start();
include "db.inc.php";

$sql = "CREATE temporary table temp_kantor select nip_baru,nama,jkel,jenis_jab,nama_jabatan,unker_induk,jenis_opd,status_pns from dbasn where status_pns='1' or status_pns='2'";  
$tem= mysql_query($sql);
$no = 1;
// nilai awal jumlah total karyawan
$totalPNSL = 0;
$totalPNSP = 0;
$totalpns=0;
$jopd1= "SELECT jenis_opd,nip_baru,jkel from temp_kantor group by jenis_opd";
$hasil=mysql_query($jopd1);
//$dopd=mysql_fetch_array($hopd2);
//$ketopd=$dopd['jenis_opd'];
//$query = "SELECT nama_jabatan,jenis_opd FROM temp_kantor where jenis_opd='$ketopd' group by jenis_opd";
//$hasil = mysql_query($query);
  while ($data = mysql_fetch_array($hasil))
  {
  
  $jenis=$data['jenis_opd'];
  $query1 = "SELECT count(*) as jum FROM temp_kantor WHERE jenis_opd = '$jenis'";
  $hasil1 = mysql_query($query1);
  $data1 = mysql_fetch_array($hasil1);
  $jumlah = $data1['jum'];
  $totalpns += $jumlah;
  
  $query2 = "SELECT count(*) as jum2 FROM temp_kantor WHERE jkel = 'L' and jenis_opd = '$jenis'";
  $hasil2 = mysql_query($query2);
  $data2 = mysql_fetch_array($hasil2);
  $jumL = $data2['jum2'];
  $totalPNSL +=$jumL; 
  
  $query3 = "SELECT count(*) as jum3 FROM temp_kantor WHERE jkel = 'P' and jenis_opd = '$jenis'";
  $hasil3 = mysql_query($query3);
  $data3 = mysql_fetch_array($hasil3);
  $jumP = $data3['jum3'];
  $totalPNSP +=$jumP;
 
 if ($jenis ==1)
   {
    $obah="Sekretariat Daerah"; //diskon 0%
   }
   else if ($jenis ==2)
   {
    $obah ="Sekretariat DPRD"; //diskon 15%
   }
   else if ($jenis ==3){
	   $obah ="Inspektorat";
   }
   else if ($jenis ==4){
	   $obah ="Dinas Daerah";
   }
   else if ($jenis ==5){
	   $obah ="Badan Daerah";
   }
   else if ($jenis ==6){
	   $obah ="RSUD";
   }
   else if ($jenis ==7){
	   $obah ="Kantor";
   }
   else if ($jenis ==A){
	   $obah ="Pelaksana Badan";
   }
         else{
	   $obah = Kecamatan;
   }
  echo "<tr><td class='text-center'>".$no."</td><td>".$obah."</td><td class='text-center'>".$jumL."</td><td class='text-center'>".$jumP."</td><td class='text-center'>".$jumlah."</td>";
 
  // increment untuk nomor urut data
  $no++;
}

echo "<tr><td colspan='2' align='center' class='text-center'><strong>Total</strong></td><td class='text-center'><strong>".$totalPNSL."</strong></td><td class='text-center'><strong>".$totalPNSP."</strong></td><td class='text-center'><strong>".$totalpns."</strong></td>";
 
// membuat akhir dari tabel

?>
</table>
<br>
</br>
</body>	