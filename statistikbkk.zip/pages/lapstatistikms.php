<!DOCTYPE html>
<html>
<head>
<style type="text/css">>
body {
			font-family: "Times New Roman", "Lucida Grande", "Segoe Ui";
		}
		
		/* Table */
		table {
			margin: auto;
			font-family: "Arial", "Lucida Grande", "Segoe Ui";
			font-size: 12px;
            text-align: center;
	        vertical-align: middle;
		}
		.demo-table {
			border-collapse: collapse;
			font-size: 12px;
		}
		.demo-table th, 
		.demo-table td {
			border-bottom: 1px solid #e1edff;
			border-left: 1px solid #e1edff;
			padding: 7px 17px;
		}
		.demo-table th, 
		.demo-table td:last-child {
			border-right: 1px solid #e1edff;
		}
		.demo-table td:first-child {
			border-top: 1px solid #e1edff;
		}
		.demo-table td:last-child{
			border-bottom: 0;
		}
		caption {
			caption-side: top;
			margin-bottom: 10px;
		}
		
		/* Table Header */
		.demo-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #7ea1cc !important;
			text-transform: uppercase;
		}
		
		/* Table Body */
		.demo-table tbody td {
			color: #353535;
		}
		
		.demo-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.demo-table tbody tr:hover th,
		.demo-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #fff21f;
			transition: all .2s;
		}
		.container{
	    display: table;
        }
      .box{
	   display: table-cell;
	   text-align: center;
	   vertical-align: middle;
	   border:50px solid rgba(0,0,0,.2);
         }
</style>
</head>
<body>
<?php $bulan = array(
                '1' => 'JANUARI',
                '2' => 'FEBRUARI',
                '3' => 'MARET',
                '4' => 'APRIL',
                '5' => 'MEI',
                '6' => 'JUNI',
                '7' => 'JULI',
                '8' => 'AGUSTUS',
                '9' => 'SEPTEMBER',
                '10' => 'OKTOBER',
                '11' => 'NOVEMBER',
                '12' => 'DESEMBER',
        );?>
		
		<div class="container">
	<section class="col-lg-12">
		<div class="table-responsive">
			<div class="page-header">
				<h2<div align="center">REKAP JUMLAH PELAMAR BKK PER PENDIDIKAN  <?php  echo ' '.(ucwords($bulan[date("m")-0])).' '.date('Y') ?></div></h2>
				<h4></h4>
			</div>
		
	    
<table id="example1" class="table table-bordered">
		<thead>
		  <tr class="danger">
          <th rowspan="3" class="text-center">No</th>
          <th rowspan="3" class="text-center">TINGKAT PENDIDIKAN</th>
          <th colspan="15" class="text-center">FORMASI</th>
		  <th rowspan="3" class="text-center">JUMLAH</th>
          </tr>
		  <tr class="danger">
		  <th colspan="3" class="text-center">PEMASARAN</th>
          <th colspan="3" class="text-center">STAF IT</th>
		  <th colspan="3" class="text-center">STAF ADMINISTRASI</th>
		  <th colspan="3" class="text-center">TELLER</th>
		  <th colspan="3" class="text-center">SATPAM</th>
		  </tr>
		  <tr class="danger">
		  <th class="text-center">MS</th>
		  <th class="text-center">TMS</th>
		  <th class="text-center">Belum Verikasi</th>
		  <th class="text-center">MS</th>
		  <th class="text-center">TMS</th>
		  <th class="text-center">Belum Verikasi</th>
		  <th class="text-center">MS</th>
		  <th class="text-center">TMS</th>
		  <th class="text-center">Belum Verikasi</th>
		  <th class="text-center">MS</th>
		  <th class="text-center">TMS</th>
		  <th class="text-center">Belum Verikasi</th>
		  <th class="text-center">MS</th>
		  <th class="text-center">TMS</th>
		  <th class="text-center">Belum Verikasi</th>
		  </tr>
		</thead>
	<tbody>			
<?php
session_start();
include "db.inc.php";

$sql = "CREATE temporary table performasims select daftar.kode_daftar,daftar.formasi,daftar.tingkat_pendidikan,tingkat_pendidikan.nama,daftar.uservalidasi,daftar.`status` from daftar join tingkat_pendidikan on daftar.tingkat_pendidikan=tingkat_pendidikan.kode order by formasi";  
$tem= mysql_query($sql);
$no = 1;
// nilai awal jumlah total karyawan
$totalPNSL = 0;
$totalPNSP = 0;
$totalpns=0;
$query = "SELECT tingkat_pendidikan,nama FROM performasims where `status`='1' group by tingkat_pendidikan";
$hasil = mysql_query($query);
while ($data = mysql_fetch_array($hasil))
{
  $pendnama=$data['tingkat_pendidikan'];
  $pendnama2=$data['nama'];
  $query1 = "SELECT count(*) as jum FROM performasims WHERE tingkat_pendidikan = '$pendnama'";
  $hasil1 = mysql_query($query1);
  $data1 = mysql_fetch_array($hasil1);
  $jumlah = $data1['jum'];
  $totalpns +=$jumlah;
  
  $query2 = "SELECT count(*) as jump1 FROM performasims WHERE formasi = '01' and tingkat_pendidikan = '$pendnama'";
  $hasil2 = mysql_query($query2);
  $data2 = mysql_fetch_array($hasil2);
  $jump1 = $data2['jump1'];
  $totpns1 +=$jump1;
}
$query = "SELECT tingkat_pendidikan,nama FROM performasims where `status`='0' group by tingkat_pendidikan";
$hasil = mysql_query($query);
while ($data = mysql_fetch_array($hasil))
  $query3 = "SELECT count(*) as jump2 FROM performasims WHERE formasi = '02' and tingkat_pendidikan = '$pendnama'";
  $hasil3 = mysql_query($query3);
  $data3 = mysql_fetch_array($hasil3);
  $jump2 = $data3['jump2'];
  $totpnsp2 +=$jump2;
  
  $query4 = "SELECT count(*) as jump3 FROM performasims WHERE formasi = '03' and tingkat_pendidikan = '$pendnama'";
  $hasil4 = mysql_query($query4);
  $data4 = mysql_fetch_array($hasil4);
  $jump3 = $data4['jump3'];
  $totpnsp3 +=$jump3;
  
  $query5 = "SELECT count(*) as jump4 FROM performasims WHERE formasi = '04' and tingkat_pendidikan = '$pendnama'";
  $hasil5 = mysql_query($query5);
  $data5 = mysql_fetch_array($hasil5);
  $jump4 = $data5['jump4'];
  $totpnsp4 +=$jump4;
  $query6 = "SELECT count(*) as jump5 FROM performasims WHERE formasi = '05' and tingkat_pendidikan = '$pendnama'";
  $hasil6 = mysql_query($query6);
  $data6 = mysql_fetch_array($hasil6);
  $jump5 = $data6['jump5'];
  $totpnsp5 +=$jump5;
 
  echo "<tr><td>".$no."</td><td>".$pendnama2."</td><td class='text-center'>".$jump1."</td><td class='text-center'>".$jump2."</td><td class='text-center'>".$jump3."</td><td class='text-center'>".$jump4."</td><td class='text-center'>".$jump5."</td><td class='text-center'>".$jumlah."</td>";
 
  // increment untuk nomor urut data
  $no++;
}
echo "<tr class='warning'><td colspan='2' align='center'>Jumlah</td><td class='text-center'>".$totpns21."</td><td class='text-center'>".$totpns22."</td><td class='text-center'>".$totpns31."</td><td class='text-center'>".$totpns32."</td><td class='text-center'>".$totpns41."</td><td class='text-center'>".$totalpns."</td>";
 
// membuat akhir dari tabel

?>
</tbody>
</table>
<p>
<br>


</div>
</body>	