<!DOCTYPE html>
<html>
<head>
<style>
table {
    border-collapse: collapse;
    width: auto;
}

th, td {
    text-align: left;
    padding: 4px 20px;
	
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>
<?php $bulan = array(
                '1' => 'JANUARI',
                '2' => 'FEBRUARI',
                '3' => 'MARET',
                '4' => 'APRIL',
                '5' => 'MEI',
                '6' => 'JUNI',
                '7' => 'JULI',
                '8' => 'AGUSTUS',
                '9' => 'SEPTEMBER',
                '10' => 'OKTOBER',
                '11' => 'NOVEMBER',
                '12' => 'DESEMBER',
        );?>
<td><table border="1" align="center">
<caption><h2><div align="center">Rekap PNS Per Golongan</div></h2>
<h3><div align="center">Bulan <?php  echo ' '.(ucwords($bulan[date("m")-1])).' '.date('Y') ?></div></h3>
</caption>
<tr>
<th>NO</th>
<th>GOLONGAN</th>
<th>LAKI-LAKI</th>
<th>PEREMPUAN</th>
<th>JUMLAH</th>
 </tr>
				
<?php
session_start();
include "db.inc.php";

$sql = "CREATE temporary table temp_gol select nip_baru,nama,jkel,gol_akhir,unker_induk,jenis_jab from dbasn where status_pns='1' or status_pns='2'";  
$tem= mysql_query($sql);
$no = 1;
// nilai awal jumlah total karyawan
$totalPNSL = 0;
$totalPNSP = 0;
$totalpns=0;
$query = "SELECT gol_akhir FROM temp_gol group by gol_akhir desc";
$hasil = mysql_query($query);
while ($data = mysql_fetch_array($hasil))
{
 $pendnama=$data['gol_akhir'];
   $query1 = "SELECT count(*) as jum FROM temp_gol WHERE gol_akhir = '$pendnama'";
  $hasil1 = mysql_query($query1);
  $data1 = mysql_fetch_array($hasil1);
  $jumlah = $data1['jum'];
  $totalpns += $jumlah;
  $query2 = "SELECT count(*) as jum2 FROM temp_gol WHERE jkel = 'L' and gol_akhir = '$pendnama'";
  $hasil2 = mysql_query($query2);
  $data2 = mysql_fetch_array($hasil2);
  $jumL = $data2['jum2'];
  $totalPNSL +=$jumL;
  
  $query3 = "SELECT count(*) as jum3 FROM temp_gol WHERE jkel = 'P' and gol_akhir = '$pendnama'";
  $hasil3 = mysql_query($query3);
  $data3 = mysql_fetch_array($hasil3);
  $jumP = $data3['jum3'];
  $totalPNSP +=$jumP;
  
  echo "<tr><td class='text-center'>".$no."</td><td class='text-center'>".$pendnama."</td><td class='text-center'>".$jumL."</td><td class='text-center'>".$jumP."</td><td class='text-center'>".$jumlah."</td>";
 
  // increment untuk nomor urut data
  $no++;
}
echo "<tr><td colspan='2' align='center'class='text-center'>Total</td><td class='text-center'>".$totalPNSL."</td><td class='text-center'>".$totalPNSP."</td><td class='text-center'>".$totalpns."</td>";
 
// membuat akhir dari tabel

?>
</table>
<p>
<br>
</body>	
</html>