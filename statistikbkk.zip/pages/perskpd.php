<!DOCTYPE html>
<html>
<head>
<style type="text/css">
		body {
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
		}
		
		/* Table */
		table {
			margin: auto;
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
			font-size: 12px;

		}
		.demo-table {
			border-collapse: collapse;
			font-size: 13px;
		}
		.demo-table th, 
		.demo-table td {
			border-bottom: 1px solid #e1edff;
			border-left: 1px solid #e1edff;
			padding: 10px 20px;
		}
		.demo-table th, 
		.demo-table td:last-child {
			border-right: 1px solid #e1edff;
		}
		.demo-table td:first-child {
			border-top: 1px solid #e1edff;
		}
		.demo-table td:last-child{
			border-bottom: 0;
		}
		caption {
			caption-side: top;
			margin-bottom: 10px;
		}
		
		/* Table Header */
		.demo-table thead th {
			background-color: #508abb;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}
		
		/* Table Body */
		.demo-table tbody td {
			color: #353535;
		}
		
		.demo-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.demo-table tbody tr:hover th,
		.demo-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
			transition: all .2s;
		}
	</style>

</head>
<body>
<?php $bulan = array(
                '1' => 'JANUARI',
                '2' => 'FEBRUARI',
                '3' => 'MARET',
                '4' => 'APRIL',
                '5' => 'MEI',
                '6' => 'JUNI',
                '7' => 'JULI',
                '8' => 'AGUSTUS',
                '9' => 'SEPTEMBER',
                '10' => 'OKTOBER',
                '11' => 'NOVEMBER',
                '12' => 'DESEMBER',
        );?>

      
	  
<div class="container">
	<section class="col-lg-15">
		<div class="table-responsive">
			<div class="page-header">
				<h2<div align="center">REKAP JUMLAH PNS Per SKPD 2017 Sampai Dengan Bulan <?php  echo ' '.(ucwords($bulan[date("m")-1])).' '.date('Y') ?></div></h2>
				<h4></h4>
			</div>
	<table id="example1" class="table table-bordered">
		<thead>
		  <tr class="danger">
          <th class="text-center">No</th>
          <th class="text-center">SKPD</th>
          <th class="text-center">PRIA</th>
          <th class="text-center">PEREMPUAN</th>
		  <th class="text-center">JUMLAH</th>
          </tr>
		</thead>
<tbody>
				
<?php
include "db.inc.php";
$sql = "CREATE temporary table temp_skpd select nip_baru,jkel,unker_induk from dbasn where status_pns='1' or status_pns='2' order by unker_induk";
$tem= mysql_query($sql);
$no = 1;
// nilai awal jumlah total karyawan
$totalPNSL = 0;
$totalPNSP = 0;
$totalpns=0;
$query = "SELECT unker_induk FROM temp_skpd group by unker_induk";
$hasil = mysql_query($query);
while ($data = mysql_fetch_array($hasil))
{
  $namaunk = $data['unker_induk'];
  $query1 = "SELECT count(*) as jum FROM temp_skpd WHERE unker_induk = '$namaunk'";
  $hasil1 = mysql_query($query1);
  $data1 = mysql_fetch_array($hasil1);
  $jumlah = $data1['jum'];
  $totalpns += $jumlah;
  $query2 = "SELECT count(*) as jum2 FROM temp_skpd WHERE jkel = 'L' and unker_induk = '$namaunk'";
  $hasil2 = mysql_query($query2);
  $data2 = mysql_fetch_array($hasil2);
  $jumL = $data2['jum2'];
  $totalPNSL +=$jumL;
  
  $query3 = "SELECT count(*) as jum3 FROM temp_skpd WHERE jkel = 'P' and unker_induk = '$namaunk'";
  $hasil3 = mysql_query($query3);
  $data3 = mysql_fetch_array($hasil3);
  $jumP = $data3['jum3'];
  $totalPNSP +=$jumP;
  
  echo "<tr><td>".$no."</td><td>".$namaunk."</td><td class='text-center'>".$jumL."</td><td class='text-center'>".$jumP."</td><td class='text-center'>".$jumlah."</td>";
 
  // increment untuk nomor urut data
  $no++;
}
echo "<tr class='warning'><td colspan='2' align='center'>Jumlah</td><td class='text-center'>".$totalPNSL."</td><td class='text-center'>".$totalPNSP."</td><td class='text-center'>".$totalpns."</td>";
 
// membuat akhir dari tabel

?>
</tbody>
</table>
</div>

<br>
<p>
</body>	
</html>
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>