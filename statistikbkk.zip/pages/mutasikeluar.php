<!DOCTYPE html>
<html>
<head>
<style>
table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    text-align: left;
    padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>
<br>
<?
include "db.inc.php";
$sql= "SELECT nip_baru,nama,tmt_pindah,jenis_sk,instansi_tujuan FROM pindah_keluar order by tmt_pindah desc;"; // Menampung perintah SQL ke variabel �sql�
?>
<div id="konten">
<p>
<p><a href="export.php"><button>Export Data ke Excel</button></a></p>
<table border='0'>
   <tr>
      <td><table border="1">
	  <caption><h2><div align="center">Data PNS Pindah Keluar Kabupaten Wonogiri<p><h3>Tahun 2015-Sekarang</h3></div></h2>
	  <h3><div align="center"></div></h3>
	  </caption>
	        <tr>
          <th>No</th>
          <th>Nip</th>
          <th>Nama PNS</th>
          <th>Tmt Pindah</th>
          <th>SK Pindah</th>
          <th>Instansi Tujuan</th>
                  </tr>
<?php
if ( $res = mysql_query($sql) ) {
    $no = 0; //variabel no untuk nomor urutnya.
	
    while ($row = mysql_fetch_array ($res)) {
     $no++; // ini sama saja dengan $no = $no + 1
		
         echo '<tr>';
          echo "<td>$no</td>";
          echo "<td>".$row['nip_baru']."</td>";
          echo "<td>".$row['nama']."</td>";
		  $tanggal=date("d-m-Y", strtotime($row['tmt_pindah']));
          echo "<td>".$tanggal."</td>";
          echo "<td>".$row['jenis_sk']."</td>";
          echo "<td>".$row['instansi_tujuan']."</td>";
          echo "</tr>";
		    }
         }
?>
      </table>
   
   </div>

  </body>
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>