<?
include "db.inc.php";
//include "session.inc.php";

//if (file_exists("Logo/".$sess_instansi.".jpg")) $gbrlogo="Logo/".$sess_instansi.".jpg";
//if (file_exists("Logo/".$sess_instansi.".gif")) $gbrlogo="Logo/".$sess_instansi.".gif";
//if (file_exists("ttd/".$sess_instansi.".jpg")) $gbrttd="ttd/".$sess_instansi.".jpg";
//if (file_exists("ttd/".$sess_instansi.".gif")) $gbrttd="ttd/".$sess_instansi.".gif";
//if (file_exists("ttd/".$sess_instansi.".png")) $gbrttd="ttd/".$sess_instansi.".png";
//if (file_exists("ttd/".$sess_instansi.".bmp")) $gbrttd="ttd/".$sess_instansi.".bmp";
//if (file_exists("kop/".$sess_instansi.".jpg")) $gbrkop="kop/".$sess_instansi.".jpg";
//else if (file_exists("kop/".$sess_instansi.".gif")) $gbrkop="kop/".$sess_instansi.".gif";
//else if (file_exists("kop/".$sess_instansi.".png")) $gbrkop="kop/".$sess_instansi.".png";
//else if (file_exists("kop/".$sess_instansi.".bmp")) $gbrkop="kop/".$sess_instansi.".bmp";
//else $gbrkop="kop/0000.png";

//$peminstansi=strtoupper(getInstansi($sess_instansi));
//$namains=substr($peminstansi,11);
//$wil=explode(" ",$namains,2);
//$namawil=$wil[1];

$q="select * from daftar where status='1'";

//$ksoal=array(1=>"C","B","A");
//$q="select a.um_nourut,a.um_nobatch,b.*,c.* from cpns_seleksi a,cpns_pdf b,dikformasi c where a.um_nodaftar=b.um_nodaftar and a.um_instansi=b.um_instansi and a.um_instansi=c.LOK_FORMASI
	//and a.um_formasi=c.FORMASI and a.um_jenis_formasi=c.JENIS_FORMASI and a.um_tkd_formasi=c.TKD_FORMASI and b.um_pendiktgg=c.KODIK_FORMASI
	//and a.um_instansi='$sess_ins' and um_status='1' ";
//if ($performasi) $q.="and a.um_formasi='$for' and a.um_jenis_formasi='$jfor' and a.um_tkd_formasi='$tkd' ";
//if ($batch!='') $q.="and a.um_nobatch='$batch' ";
//if ($nd!='') $q.="and a.um_nodaftar='$nd' ";
//$q.="order by a.um_nourut";
$r=mysql_query($q) or die(mysql_error());
$jmlsrt=mysql_num_rows($r);
$nosrt=0;
?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Surat Undangan Tes</title>
<style>
<!--
a:active     { text-decoration: none; color:#000000 }
a            { text-decoration: none; color:#000000 }
a:link       { text-decoration: none; color:#000000 }
a:visited    { text-decoration: none; color:#000000 }
body         { font-family: Tahoma; font-size:10pt }
td           { font-family: Tahoma; font-size: 10pt }
-->
</style>
</head>

<body>
<?
while ($row=mysql_fetch_array($r)) {
	$nosrt++;
	//$qtmp="select st_id,st_noruang from setuptt where st_instansi='$sess_ins' and st_formasi='$row[um_formasi]' and st_jenis_formasi='$row[um_jenis_formasi]' and st_tkd_formasi='$row[um_tkd_formasi]' and st_nobatch='$row[um_nobatch]'";
	//$rtmp=mysql_query($qtmp) or die(mysql_error());
	//$rotmp=mysql_fetch_row($rtmp);

	//$qtt="select tt_gedung,tt_alamat from tempattes where tt_instansi='$sess_ins' and tt_id='$rotmp[0]'";
	//$rtt=mysql_query($qtt) or die(mysql_error());
	//$rott=mysql_fetch_row($rtt);

	switch (strlen($row[um_no_daftar])) {
		/*case 1: $nourut="0000".$row[0];break;
		case 2: $nourut="000".$row[0];break;*/
		case 1: $nourut="00".$row[0];break;
		case 2: $nourut="0".$row[0];break;
		case 3: $nourut=$row[0];break;
	}
?>
<table border="0" width="685" id="table1" cellpadding="0" style="border-collapse: collapse" <?= $nosrt!=$jmlsrt ? "style=\"page-break-after: always\"":""?>>
	<tr>
		<td><!--<img border="0" src="<?//=$gbrkop?>" width="685"></td>-->
	</tr>
	<tr>
		<td>
		<table border="0" width="100%" id="table9" cellspacing="0" cellpadding="0">
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="42%" colspan="2">&nbsp;</td>
				<td width="3%">&nbsp;</td>
				<td width="46%"><?//=$rowkota[INS_KOTA]?>, <?//=formatTanggalPanjang(date("Y-m-d"));?></td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="42%" colspan="2">&nbsp;</td>
				<td width="3%">&nbsp;</td>
				<td width="46%">&nbsp;</td>
			</tr>
			<tr>
				<td width="8%"><b>Nomor</b></td>
				<td width="2%"><b>:</b></td>
				<td width="42%" colspan="2">&nbsp;</td>
				<td width="3%">&nbsp;</td>
				<td width="46%" rowspan="5" valign="top">Kepada Yth:<br>
<?=$row[nama]?><br><?=$row[alamat]?><?=$row[desa]!='' ? " KEL/DESA ".$row[desa] : ""?><?=$row[kecamatan]!='' ? " KEC. ".$row[kecamatan] : ""?><br><?=$row[kabupaten]?>  <?=$row[nohp]?></td>
			</tr>
			<tr>
				<td width="8%"><b>Sifat</b></td>
				<td width="2%"><b>:</b></td>
				<td width="42%" colspan="2"><b>Amat Segera</b></td>
				<td width="3%">&nbsp;</td>
			</tr>
			<tr>
				<td width="8%"><b>Perihal</b></td>
				<td width="2%"><b>:</b></td>
				<td width="42%" colspan="2"><b>Undangan Ujian Tertulis</b></td>
				<td width="3%">&nbsp;</td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="41%" colspan="2">&nbsp;</td>
				<td width="3%">&nbsp;</td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="15%">&nbsp;</td>
				<td width="26%">&nbsp;</td>
				<td width="3%">&nbsp;</td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td colspan="4">
				<p align="justify">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Berdasarkan hasil 
				seleksi administrasi terhadap 
		berkas lamaran Saudara, bersama ini dengan hormat disampaikan bahwa 
		Saudara dinyatakan <b>Memenuhi Syarat (MS)</b> dan berhak mengikuti 
				Tes Komptensi Dasar (TKD).<br>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		Sehubungan dengan hal tersebut diharapkan kehadiran Saudara untuk 
		mengikuti <b>ujian tertulis</b> seleksi Penerimaan Pegawai Non PNS BLUD RSUD dr. Soediran Mangun Sumarso  <?//=substr(getInstansi($sess_instansi),10)?>  pada:</td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="15%">Hari / Tanggal</td>
				<td width="76%" colspan="3">: Minggu, 6 Desember 2009</td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="15%">Jam</td>
				<td width="76%" colspan="3">: 09.00 WIB</td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="15%">Tempat</td>
				<td width="76%" colspan="3">:  Komplek GOR Giri Mandala Wonogiri         <?/*=$rott[0]*/?> 
				<b><?/*=$rotmp[1]*/?></b>&nbsp;<?/*=$rott[1]*/?></td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="90%" colspan="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Demikian untuk menjadikan perhatian.</td>
			</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td>
		<table border="0" width="100%" id="table3" cellspacing="0" cellpadding="0">
			<tr>
				<td>&nbsp;</td>
				<td width="328">
				<p align="center"><b>
				<?//=$rowkota[INS_DUK]?> RSUD dr.SOEDIRAN MANGUN SUMARSO <br>
				<?//= $peminstansi ?><br>
				</b></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td width="328" align="center"><img border="0" src="<?=$gbrttd?>" height="40"></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td width="300" align="center">
				<b><? //if ($rowkota[INS_PKT_SEKDA]!='') {?><u><?//=$rowkota[INS_NM_SEKDA]?></u><?//} else {?><?//=$rowkota[INS_NM_SEKDA]?><?// } ?><br>
				<?//=$pkt[$rowkota[INS_PKT_SEKDA]]?><br><?// if ($rowkota[INS_NIP_SEKDA]!='') echo "NIP. ".$rowkota[INS_NIP_SEKDA]?></b></td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td>
		<table border="0" width="100%" id="table10" cellspacing="0" cellpadding="0">
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="23%"><b>Catatan :</b></td>
				<td width="18%">&nbsp;</td>
				<td width="3%">&nbsp;</td>
				<td width="46%">&nbsp;</td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="90%" colspan="4">1.<b> Hadir 30 menit sebelum 
				pelaksanaan</b></td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="90%" colspan="4">2. Wajib Membawa perlengkapan :</td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="90%" colspan="4">&nbsp;&nbsp;&nbsp; - Alat tulis : 
				Pensil 2B, ballpoint, penghapus karet dan alas tulis</td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="90%" colspan="4">&nbsp;&nbsp;&nbsp; - Asli kartu tes</td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="90%" colspan="4">&nbsp;&nbsp;&nbsp; - Asli Kartu 
				Tanda Penduduk (KTP)</td>
			</tr>
			<tr>
				<td width="8%">&nbsp;</td>
				<td width="2%">&nbsp;</td>
				<td width="90%" colspan="4">3. Pakaian bebas rapi (bukan kaos) 
				dan memakai sepatu</td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td style="border-left-width: 1px; border-right-width: 1px; border-top-width: 1px; border-bottom: 2px dashed #000000">&nbsp;
		</td>
	</tr>
	<tr>
		<td>
		<table border="0" width="100%" id="table6" cellpadding="0" style="border-collapse: collapse">
			<tr>
				<td align="center" style="border-left-width: 1px; border-right-width: 1px; border-top-width: 1px; ">
	<b>KARTU TANDA PENGENAL<br>
		PESERTA SELEKSI PENERIMAAN PEGAWAI NON PNS BLUD 
		<?//=strtoupper(substr(getInstansi($sess_instansi),11))?>
				<br>
				TAHUN 2016 </b></td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td>
		<table border="0" width="100%" id="table4" cellspacing="0" cellpadding="0">
			<tr>
				<td width="179">&nbsp;</td>
				<td width="23">&nbsp;</td>
				<td width="270">&nbsp;</td>
				<td align="center">&nbsp;</td>
			</tr>
			<tr>
				<td width="179">Nama</td>
				<td width="23">:</td>
				<td width="270"><?=$row[nama]?></td>
				<td align="center"><b>NOMOR TEST / UJIAN</b></td>
			</tr>
			<tr>
				<td width="179">Tempat Tanggal Lahir</td>
				<td width="23">:</td>
				<td width="270"><?=$row[temp_lahir]?> / <?=($row[tgl_lahir])?></td>
				<td align="center"><b><?//=$row[um_instansi]?>.<?//=$row[um_formasi]?><?//=//$row[um_jenis_formasi]?><?//=$row[um_tkd_formasi]?>.<?=$nourut?></b></td>
			</tr>
			<tr>
				<td width="179">Pendidikan</td>
				<td width="23">:</td>
				<td colspan="2"><?//=getPendidikan($row[um_pendiktgg])?> <?//= $row[KET_DIK]!='' ? "+ ".$row[KET_DIK] : ""?></td>
			</tr>
			<tr>
				<td width="179">Formasi</td>
				<td width="23">:</td>
				<td colspan="2"><?=$row[formasi]//=getFormasiUmumKet($row[um_formasi],$row[um_jenis_formasi],$row[um_tkd_formasi])?></td>
			</tr>
			<tr>
				<td width="179">Tempat Tes/Ujian Tertulis</td>
				<td width="23">:</td>
				<td colspan="2">Komplek GOR Giri Mandala Wonogiri  </td>
			</tr>
		</table>
		</td>
	</tr> 
	<tr>
		<td style="border-left-width: 1px; border-right-width: 1px; border-top-width: 1px; border-bottom: 2px dashed #000000">
		<table border="0" width="100%" id="table5" cellspacing="0" cellpadding="0">
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td align="center">&nbsp;</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td>&nbsp;</td>
				<td align="center"><?//=$rowkota[INS_KOTA]?>, 20 Desember 2016</td>
			</tr>
			<tr>
				<td valign="top">Perhatian:<br>
		Kartu pengenal ini WAJIB dibawa<br>
		pada saat mengikuti tes</td>
				<td width="97" rowspan="2">
				<p align="center"><p></td>
				<td width="331">
				<p align="center"><b><?//=//$rowkota[INS_DUK]?>
				  RSUD dr.SOEDIRAN MANGUN SUMARSO<br>
				<?//=// $peminstansi ?><br>
			  </b></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td width="331" align="center"><img border="0" src="<?=$gbrttd?>" height="40">				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td width="99" style="padding-left: 4px; padding-right: 4px; padding-top: 1px; padding-bottom: 1px">&nbsp;
				
				</td>
				<td width="331"><p align="center"><b><? //if ($rowkota[INS_PKT_SEKDA]!='') {?><u><?//=$rowkota[INS_NM_SEKDA]?></u><?//} else {?><?//=$rowkota[INS_NM_SEKDA]?><?// } ?>
				<br><?//=$pkt[$rowkota[INS_PKT_SEKDA]]?><br><?// if ($rowkota[INS_NIP_SEKDA]!='') echo "NIP. ".$rowkota[INS_NIP_SEKDA]?></b></td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td style="border-left-width: 1px; border-right-width: 1px; border-top-width: 1px; border-bottom: 2px dashed #000000">
		<table border="0" width="100%" id="table11" cellspacing="0" cellpadding="0">
			<tr>
				<td colspan="4" align="center"><b>KARTU PENGENAL 
				PESERTA SELEKSI PENERIMAAN PEGAWAI NON PNS BLUD<br>
				<?//=strtoupper(substr(getInstansi($sess_instansi),11))?>
				TAHUN 2016 </b></td>
			</tr>
			<tr>
				<td width="26%">NOMOR TEST / UJIAN</td>
				<td width="3%">:</td>
				<td width="60%"><?//=$row[um_instansi]?>.<?=$row[formasi]?><?//=$row[um_jenis_formasi]?><?//=$row[um_tkd_formasi]?>.<?=$nourut?></td>
				<td align="center" rowspan="6" width="11%">
				<table border="1" width="100%" id="table13" height="92" style="border-collapse: collapse" bordercolor="#000000">
					<tr>
						<td>
						<p align="center">Pas Foto<br>
						4 x 6 cm</td>
					</tr>
				</table>
				</td>
			</tr>
			<tr>
				<td width="26%">Nama</td>
				<td width="3%">:</td>
				<td width="60%"><?=$row[nama]?></td>
			</tr>
			<tr>
				<td width="26%">Tempat Tanggal Lahir</td>
				<td width="3%">:</td>
				<td width="60%"><?=$row[temp_lahir]?> / <?=$row[tgl_lahir]?></td>
			</tr>
			<tr>
				<td width="26%">Pendidikan</td>
				<td width="3%">:</td>
				<td width="60%"><?//=getPendidikan($row[um_pendiktgg])?> <?//= $row[KET_DIK]!='' ? "+ ".$row[KET_DIK] : ""?></td>
			</tr>
			<tr>
				<td width="26%">Formasi</td>
				<td width="3%">:</td>
				<td width="60%"><?=$row[formasi]//=getFormasiUmumKet($row[um_formasi],$row[um_jenis_formasi],$row[um_tkd_formasi])?></td>
			</tr>
			<tr>
				<td width="26%">Tempat Tes/Ujian Tertulis</td>
				<td width="3%">:</td>
				<td width="60%">Komplek GOR Giri Mandala Wonogiri      <?/*$rott[0]?> <b>Ruang <?=$rotmp[1]?></b> <?=$rott[1]*/?></td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td>
		<table border="0" width="100%" id="table12" cellspacing="0" cellpadding="0">
			<tr>
				<td colspan="4">
				<table border="0" width="100%" id="table14" style="border-collapse: collapse">
					<tr>
						<td width="131">
						<table border="1" id="table15" bgcolor="#C0C0C0" style="border-collapse: collapse" bordercolor="#000000">
							<tr>
								<td>NOMOR TEMPEL MEJA</td>
							</tr>
						</table>
						</td>
						<td align="center"><b>PELAKSANAAN 
						SELEKSI PENERIMAAN PEGAWAI NON PNS BLUD<br>
						<?//=strtoupper(substr(getInstansi($sess_instansi),11))?><br>
					  TAHUN  2016</b></td>
						<td width="133">&nbsp;</td>
					</tr>
				</table>
				</td>
			</tr>
			<tr>
				<td width="179">Nama</td>
				<td width="23">:</td>
				<td width="270"><?=$row[nama]?></td>
				<td align="center"><b>NOMOR TEST / UJIAN</b></td>
			</tr>
			<tr>
				<td width="179">Tempat Tanggal Lahir</td>
				<td width="23">:</td>
				<td width="270"><?=$row[temp_lahir]?> / <?=$row[tgl_lahir]?></td>
				<td align="center"><b><?//=$row[um_instansi]?>.<?=$row[formasi]?><?//=$row[um_jenis_formasi]?><?//=$row[um_tkd_formasi]?>.<?=$nourut?></b></td>
			</tr>
			<tr>
				<td width="179">Pendidikan</td>
				<td width="23">:</td>
				<td colspan="2"><?//=getPendidikan($row[um_pendiktgg])?> <?//= $row[KET_DIK]!='' ? "+ ".$row[KET_DIK] : ""?></td>
			</tr>
			<tr>
				<td width="179">Formasi</td>
				<td width="23">:</td>
				<td colspan="2"><?=$row[formasi]//=getFormasiUmumKet($row[um_formasi],$row[um_jenis_formasi],$row[um_tkd_formasi])?></td>
			</tr>
			<tr>
				<td width="179">Tempat Tes/Ujian Tertulis</td>
				<td width="23">:</td>
				<td colspan="2">Komplek GOR Giri Mandala Wonogiri </td>
			</tr>
		</table>
		</td>
	</tr>
	</table>
<? } ?>
</body>

</html>