<!DOCTYPE html>
<html>
<head>
<style>
table {
    border-collapse: collapse;
    width: auto;
}

th, td {
    text-align: left;
    padding: 4px 20px;
	
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>
<?php $bulan = array(
                '1' => 'JANUARI',
                '2' => 'FEBRUARI',
                '3' => 'MARET',
                '4' => 'APRIL',
                '5' => 'MEI',
                '6' => 'JUNI',
                '7' => 'JULI',
                '8' => 'AGUSTUS',
                '9' => 'SEPTEMBER',
                '10' => 'OKTOBER',
                '11' => 'NOVEMBER',
                '12' => 'DESEMBER',
        );?>
<td><table border="1" align="center">
<caption><h2><div align="center">Rekap PNS Per Tingkat Pendidikan</div></h2>
<h3><div align="center">Bulan <?php  echo ' '.(ucwords($bulan[date("m")-1])).' '.date('Y') ?></div></h3>
</caption>
<tr></tr>
<tr>
<th>NO</th>
<th>TINGKAT PENDIDIKAN</th>
<th>LAKI-LAKI</th>
<th>PEREMPUAN</th>
<th>JUMLAH</th>
 </tr>
				
<?php
session_start();
include "db.inc.php";

$sql = "CREATE temporary table temp_pend select nip_baru,nama,jkel,pendidikan_akhir,unker_induk,tingkat_pendidikan2 from dbasn where status_pns='1' or status_pns='2'";  
$tem= mysql_query($sql);
$no = 1;
// nilai awal jumlah total karyawan
$totalPNSL = 0;
$totalPNSP = 0;
$totalpns=0;

$query = "SELECT tingkat_pendidikan.nama,temp_pend.tingkat_pendidikan2 FROM temp_pend,tingkat_pendidikan where tingkat_pendidikan.kode=temp_pend.tingkat_pendidikan2 group by tingkat_pendidikan2";
$hasil = mysql_query($query);
while ($data = mysql_fetch_array($hasil))
{
 $pendnama=$data['nama'];
  $pend = $data['tingkat_pendidikan2'];
  $query1 = "SELECT count(*) as jum FROM temp_pend WHERE tingkat_pendidikan2 = '$pend'";
  $hasil1 = mysql_query($query1);
  $data1 = mysql_fetch_array($hasil1);
  $jumlah = $data1['jum'];
  $totalpns += $jumlah;
  $query2 = "SELECT count(*) as jum2 FROM temp_pend WHERE jkel = 'L' and tingkat_pendidikan2 = '$pend'";
  $hasil2 = mysql_query($query2);
  $data2 = mysql_fetch_array($hasil2);
  $jumL = $data2['jum2'];
  $totalPNSL +=$jumL;
  
  $query3 = "SELECT count(*) as jum3 FROM temp_pend WHERE jkel = 'P' and tingkat_pendidikan2 = '$pend'";
  $hasil3 = mysql_query($query3);
  $data3 = mysql_fetch_array($hasil3);
  $jumP = $data3['jum3'];
  $totalPNSP +=$jumP;
  
  echo "<tr><td>".$no."</td><td>".$pendnama."</td><td>".$jumL."</td><td>".$jumP."</td><td>".$jumlah."</td>";
 
  // increment untuk nomor urut data
  $no++;
}
echo "<tr><td colspan='2' align='center'>Total</td><td>".$totalPNSL."</td><td>".$totalPNSP."</td><td>".$totalpns."</td>";
 
// membuat akhir dari tabel

?>
</table>
</body>	